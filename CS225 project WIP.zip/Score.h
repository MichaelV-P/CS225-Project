//
// Created by deade on 4/8/2022.
//

#ifndef UNTITLED11_SCORE_H
#define UNTITLED11_SCORE_H
#include <iostream>
using namespace std;
class Score {
public:
    Score();
    int cPoints = 0;
    int streak = 0;
};
#endif //UNTITLED11_SCORE_H
