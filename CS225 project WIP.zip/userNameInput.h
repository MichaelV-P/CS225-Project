//
// Created by deade on 4/8/2022.
//

#ifndef UNTITLED11_USERNAMEINPUT_H
#define UNTITLED11_USERNAMEINPUT_H
#pragma once
#include <string>
#include <iostream>

using namespace std;

string userNameInput();
#endif //UNTITLED11_USERNAMEINPUT_H
